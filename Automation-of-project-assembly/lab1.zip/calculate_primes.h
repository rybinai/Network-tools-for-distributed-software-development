void calculate_primes ();
